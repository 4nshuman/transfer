# Tasks: Demo Checkout Flow

- [ ] T001 Add idempotency-key generation helper.
- [ ] T002 Add checkout ownership validation.
- [ ] T003 Add payment-provider adapter boundary.
- [ ] T004 Add transactional order creation.
- [ ] T005 Add integration tests for success, rejected payment, and duplicate submit.
- [ ] T006 Add feature-flag rollout and rollback notes.

