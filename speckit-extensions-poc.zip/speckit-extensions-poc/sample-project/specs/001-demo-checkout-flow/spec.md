# Feature Spec: Demo Checkout Flow

## User Stories

### Story 1: Submit checkout

As a shopper, I can submit my cart for payment so that I can complete a purchase.

### Story 2: Recover from payment failure

As a shopper, I can retry or choose another payment method when the payment provider rejects the payment.

## Acceptance Criteria

1. Given a valid cart and payment method, when the shopper submits checkout, then an order is created.
2. Given the payment provider rejects the payment, when the shopper returns to checkout, then the cart remains intact.
3. Given a duplicate submit request, when the request is replayed, then only one order is created.

## Risks

- Payment flow must avoid duplicate orders.
- Authorization must prevent shoppers from submitting someone else's cart.

