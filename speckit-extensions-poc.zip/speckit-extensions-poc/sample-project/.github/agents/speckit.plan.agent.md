---
description: "Spec Kit implementation planning agent."
tools: []
---

# Spec Kit Plan Agent

This is a minimal Copilot default-mode sample for the core `speckit.plan` agent.

In a real project, `specify init --integration copilot` creates the full managed `speckit.plan.agent.md` from Spec Kit's built-in templates.

This placeholder exists only to show where extension hooks attach in a Copilot-only project.

