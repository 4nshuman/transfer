---
description: "Generate a product-readiness report from Spec Kit artifacts."
tools: []
---

# Product Gate: Report

This is the Copilot default-mode registered agent file produced from the extension command.

Dispatch it directly with:

```bash
copilot -p "" --agent speckit.product-gate.report
```

Create or update `specs/<feature>/product-gate-report.md` with story coverage, acceptance-criteria coverage, task mapping, risks, open questions, and go/no-go status.

