---
description: "Review Spec Kit artifacts for product-readiness risks."
tools: []
---

# Product Gate: Quality Gate

This is the Copilot default-mode registered agent file produced from the extension command.

Dispatch it directly with:

```bash
copilot -p "" --agent speckit.product-gate.quality-gate
```

Inspect `spec.md`, `plan.md`, optional `tasks.md`, the project constitution, and `.specify/extensions/product-gate/product-gate-config.yml`.

Return `PASS`, `WARN`, or `BLOCKED` with file-grounded evidence and required artifact fixes.

