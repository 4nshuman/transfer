---
description: "Spec Kit task generation agent."
tools: []
---

# Spec Kit Tasks Agent

This is a minimal Copilot default-mode sample for the core `speckit.tasks` agent.

In a real project, `specify init --integration copilot` creates the full managed `speckit.tasks.agent.md` from Spec Kit's built-in templates.

This placeholder exists only to show where extension hooks attach in a Copilot-only project.

