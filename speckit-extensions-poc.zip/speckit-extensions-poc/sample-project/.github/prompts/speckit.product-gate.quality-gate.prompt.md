---
agent: speckit.product-gate.quality-gate
---

