---
agent: speckit.product-gate.report
---

