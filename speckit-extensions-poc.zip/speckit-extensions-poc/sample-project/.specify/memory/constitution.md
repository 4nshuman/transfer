# Project Constitution

## Principles

1. User-facing changes must have clear acceptance criteria.
2. Implementation plans must include test strategy and rollback or recovery notes.
3. Features touching payments, authentication, authorization, or migrations require explicit risk treatment.

