# Spec Kit Extension And Bundle POC For GitHub Copilot

This POC shows how Spec Kit extensions and bundles work when the project is initialized for GitHub Copilot.

It is intentionally Copilot-only. The sample installed project models Spec Kit's current default Copilot integration mode: `.github/agents/*.agent.md` command agents, `.github/prompts/*.prompt.md` companion prompts, and `.vscode/settings.json`.

It contains four pieces:

- `extension-source/product-gate/`: the extension package an author would publish or install with `--dev`.
- `bundle-source/product-readiness-stack/`: the bundle package that pins and installs the extension as a curated stack.
- `sample-project/`: an initialized-project-style view of what the extension looks like after installation.
- `local-catalog/catalog.json`: a minimal catalog showing how extension and bundle discovery work.

The sample extension is `product-gate`. It adds a quality gate to the normal Spec Kit lifecycle:

1. After the Copilot-backed `speckit.plan` agent, run `speckit.product-gate.quality-gate`.
2. After the Copilot-backed `speckit.tasks` agent, offer the optional `speckit.product-gate.report` command.
3. Load project config from `.specify/extensions/product-gate/product-gate-config.yml`.
4. Allow local/environment overrides without committing secrets or personal preferences.

## What This Demonstrates

### 1. Manifest-driven installation

`extension-source/product-gate/extension.yml` declares:

- extension identity: `id`, `name`, `version`, `description`
- compatibility: required Spec Kit version and required core commands
- provided commands: `speckit.product-gate.quality-gate`, `speckit.product-gate.report`
- config files: template and project config
- hooks: lifecycle events where commands should run
- defaults: baseline configuration values

Spec Kit validates this manifest during `specify extension add`.

### 2. Command registration

Each command is a markdown file under `commands/`.

When the extension is installed into a Copilot project, Spec Kit registers those commands as Copilot agents:

```text
sample-project/.github/agents/speckit.product-gate.quality-gate.agent.md
sample-project/.github/agents/speckit.product-gate.report.agent.md
```

It also creates companion Copilot prompt files:

```text
sample-project/.github/prompts/speckit.product-gate.quality-gate.prompt.md
sample-project/.github/prompts/speckit.product-gate.report.prompt.md
```

In Copilot default agent mode, these are not slash commands. Copilot CLI dispatch selects the agent by name:

```bash
copilot -p "" --agent speckit.product-gate.quality-gate
copilot -p "" --agent speckit.product-gate.report
```

### 3. Extension install state

Installed extensions live under:

```text
sample-project/.specify/extensions/product-gate/
```

The project registry is represented by:

```text
sample-project/.specify/extensions/.registry
```

### 4. Hooks

Hooks are represented in:

```text
sample-project/.specify/extensions.yml
```

This sample registers:

- mandatory `after_plan` hook: quality gate
- optional `after_tasks` hook: report generation

### 5. Catalogs

Catalogs are how teams expose trusted extensions and bundles by name. The POC includes:

```text
local-catalog/catalog.json
sample-project/.specify/extension-catalogs.yml
sample-project/.specify/bundle-catalogs.yml
```

That shows how an organization can point Spec Kit at internal catalogs instead of asking every engineer to install from arbitrary URLs.

### 6. Bundle composition

The sample bundle is `product-readiness-stack`. It does not add new Copilot behavior. It pins and installs existing Spec Kit primitives:

```text
bundle-source/product-readiness-stack/bundle.yml
```

In this POC it contributes:

```text
extension: product-gate@1.0.0
```

Installed bundle provenance is represented by:

```text
sample-project/.specify/bundle-records.json
```

That provenance is what lets Spec Kit list, update, and remove a bundle without guessing which primitive files belong to it.

## Run Against A Real Spec Kit Project

Install Spec Kit if `specify` is not already available:

```bash
python -m uv tool install specify-cli --from git+https://github.com/github/spec-kit.git@v0.12.5
specify version
```

Use `uv tool install ...` directly only when the `uv` executable is already on your PATH.

From a real project already initialized with Copilot default agent mode:

```bash
specify init --here --integration copilot
```

Then install the sample extension:

```bash
specify extension add --dev /Users/4nshuman/Development/speckit-extensions-poc/extension-source/product-gate
specify extension list
specify extension info product-gate
```

Or install the bundle that owns the same extension stack:

```bash
specify extension catalog add file:///Users/4nshuman/Development/speckit-extensions-poc/local-catalog/catalog.json --name local-poc-catalog --install-allowed
specify bundle install /Users/4nshuman/Development/speckit-extensions-poc/bundle-source/product-readiness-stack
specify bundle list
```

Then run the normal Copilot-backed lifecycle through the generated Copilot agents/prompts:

```text
speckit.plan
speckit.tasks
```

The hooks would be surfaced by Spec Kit around those lifecycle commands. The extension agents can also be dispatched directly with Copilot CLI:

```bash
copilot -p "" --agent speckit.product-gate.quality-gate
copilot -p "" --agent speckit.product-gate.report
```

## Read This First

For the shortest path through the POC, read:

1. `docs/copilot-extension-understanding.md`
2. `docs/bundle-lifecycle.md`
3. `docs/extension-lifecycle.md`
4. `extension-source/product-gate/extension.yml`
5. `bundle-source/product-readiness-stack/bundle.yml`
6. `sample-project/.specify/extensions.yml`
7. `sample-project/.specify/bundle-records.json`
