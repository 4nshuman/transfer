# How Spec Kit Extensions Work With Copilot

This POC models the extension lifecycle at a file level for GitHub Copilot default agent mode.

## Lifecycle

```mermaid
flowchart TD
    A["Extension author creates extension.yml"] --> B["Author adds commands/*.md"]
    B --> C["Optional config templates, defaults, and hooks"]
    C --> D["User runs specify extension add"]
    D --> E["Spec Kit validates manifest and compatibility"]
    E --> F["Spec Kit copies extension into .specify/extensions/{id}"]
    F --> G["Spec Kit registers Copilot .agent.md and .prompt.md files"]
    G --> H["Spec Kit records install state in .specify/extensions/.registry"]
    H --> I["Spec Kit registers lifecycle hooks in .specify/extensions.yml"]
    I --> J["Core lifecycle command surfaces or executes hook command"]
```

## Extension Source Package

An extension source package is portable. It can be local, zipped, or referenced from a catalog.

```text
extension-source/product-gate/
├── extension.yml
├── product-gate-config.template.yml
├── commands/
│   ├── quality-gate.md
│   └── report.md
├── scripts/
│   └── summarize-artifacts.sh
├── .extensionignore
└── README.md
```

## Installed Project State

After installation, the project has a copy of the extension plus registry/config/hook state:

```text
sample-project/
├── .specify/
│   ├── extension-catalogs.yml
│   ├── extensions.yml
│   ├── extensions/
│   │   ├── .registry
│   │   └── product-gate/
│   │       ├── extension.yml
│   │       ├── product-gate-config.yml
│   │       └── commands/
│   └── memory/
│       └── constitution.md
├── .github/
│   ├── agents/
│   │   ├── speckit.product-gate.quality-gate.agent.md
│   │   └── speckit.product-gate.report.agent.md
│   └── prompts/
│       ├── speckit.product-gate.quality-gate.prompt.md
│       └── speckit.product-gate.report.prompt.md
├── .vscode/
│   └── settings.json
└── specs/
    └── 001-demo-checkout-flow/
```

## What The Extension Adds

The extension adds domain policy on top of the base Spec Kit workflow. Base Spec Kit can produce specs, plans, and tasks. This extension asks one extra question:

> Are the generated artifacts good enough to proceed?

It does that by adding:

- a command that reviews spec/plan/tasks against configurable gates
- a lifecycle hook that runs after planning
- an optional report command after task generation
- config files so the project can tune strictness

## Why This Matters

Extensions are best for reusable team behavior:

- quality gates
- domain-specific commands
- integrations with Jira, Linear, Azure DevOps, GitHub, security tools, observability tools
- workflow enforcement
- generated reports

They are not meant for one-off requirements that belong directly in a single feature spec.
