# How Spec Kit Bundles Work

This POC models the bundle lifecycle at a file level, building on the existing `product-gate` extension.

## Bundle Mental Model

An extension adds behavior. A preset changes resolved templates. A workflow automates steps. A bundle does not add new runtime behavior by itself.

A bundle is a curated install plan:

```text
bundle.yml
  -> pins component IDs and versions
  -> resolves them through normal catalogs or local/bundled sources
  -> installs each component through that component's own machinery
  -> writes bundle provenance for list, update, and removal
```

In this POC, the bundle is:

```text
bundle-source/product-readiness-stack/
├── bundle.yml
└── README.md
```

It installs:

```text
product-gate extension, version 1.0.0
```

## Lifecycle

```mermaid
flowchart TD
    A["Bundle author creates bundle.yml"] --> B["Bundle pins component refs"]
    B --> C["User runs specify bundle install"]
    C --> D["Spec Kit resolves bundle source or catalog entry"]
    D --> E["Spec Kit validates manifest and version pins"]
    E --> F["Spec Kit checks active integration compatibility"]
    F --> G["Spec Kit installs each primitive through its own installer"]
    G --> H["Extension installer registers product-gate commands and hooks"]
    H --> I["Spec Kit writes .specify/bundle-records.json"]
```

## Bundle Source Package

The required source file is:

```text
bundle-source/product-readiness-stack/bundle.yml
```

That manifest declares:

- bundle identity: `id`, `name`, `version`, `role`, `description`
- compatibility: required Spec Kit version
- integration policy: omitted here, so the bundle inherits the active project integration
- provided components: the pinned `product-gate@1.0.0` extension
- tags for discovery

## Catalog Discovery

The local catalog now exposes both the primitive extension and the bundle:

```text
local-catalog/catalog.json
```

For bundle discovery, a project points Spec Kit at that catalog through:

```text
sample-project/.specify/bundle-catalogs.yml
```

The bundle catalog entry advertises `product-readiness-stack`, the required Spec Kit version, component counts, and a download URL for the built bundle artifact.

## Installed Project State

After a bundle install, the primitive's files still land where the primitive normally writes them. For this POC, the extension still appears under:

```text
sample-project/.specify/extensions/product-gate/
sample-project/.github/agents/speckit.product-gate.quality-gate.agent.md
sample-project/.github/prompts/speckit.product-gate.quality-gate.prompt.md
```

The bundle-specific install state is separate:

```text
sample-project/.specify/bundle-records.json
```

That record says which components this bundle contributed. Spec Kit uses it so `specify bundle remove product-readiness-stack` removes only components owned by that bundle and leaves components that another bundle still needs.

## Why The Bundle Layer Matters

Installing the extension directly answers:

```text
"How do I add this product gate behavior to one project?"
```

Installing the bundle answers:

```text
"How do I provision a whole product-engineering setup consistently?"
```

The practical difference is ownership and curation:

- the extension owns command files, config, hooks, and Copilot registration
- the bundle owns the stack definition, version pins, catalog entry, conflict checks, and provenance
- bundle update re-resolves the stack and refreshes owned primitives
- bundle removal avoids collateral cleanup by consulting `.specify/bundle-records.json`

## Commands To Try

Install from the local bundle source:

```bash
specify bundle install /Users/4nshuman/Development/speckit-extensions-poc/bundle-source/product-readiness-stack
```

Inspect what would be installed from a catalog:

```bash
specify bundle catalog add file:///Users/4nshuman/Development/speckit-extensions-poc/local-catalog/catalog.json --id local-poc-bundles --policy install-allowed
specify bundle search product-readiness
specify bundle info product-readiness-stack
```

Build a distributable artifact:

```bash
specify bundle validate --path /Users/4nshuman/Development/speckit-extensions-poc/bundle-source/product-readiness-stack
specify bundle build --path /Users/4nshuman/Development/speckit-extensions-poc/bundle-source/product-readiness-stack --output /Users/4nshuman/Development/speckit-extensions-poc/dist
```
