# Walkthrough: Product Gate Extension For Copilot

This walkthrough explains the POC in the same order Spec Kit handles an extension in a GitHub Copilot project.

This sample uses Copilot default agent mode only. It does not include any other Spec Kit integration layout.

## 1. Author Creates Extension Source

The source package is:

```text
extension-source/product-gate/
```

The required file is:

```text
extension-source/product-gate/extension.yml
```

That manifest declares the extension ID, compatibility, commands, config, hooks, and defaults.

## 2. User Installs Extension

From a real Spec Kit project initialized for Copilot:

```bash
specify init --here --integration copilot
```

Then install the extension:

```bash
specify extension add --dev /absolute/path/to/extension-source/product-gate
```

The `--dev` flag means install from a local directory instead of a catalog/release URL.

## 3. Spec Kit Copies The Extension

The extension is copied into the initialized project:

```text
.specify/extensions/product-gate/
```

This POC shows that installed state at:

```text
sample-project/.specify/extensions/product-gate/
```

## 4. Spec Kit Updates The Registry

Spec Kit records install metadata in:

```text
.specify/extensions/.registry
```

The POC registry shows:

- installed extension ID: `product-gate`
- version: `1.0.0`
- source: `dev`
- registered commands
- registered hook events
- enabled state

## 5. Spec Kit Registers Commands With Copilot

The manifest provides:

```text
speckit.product-gate.quality-gate
speckit.product-gate.report
```

The Copilot default integration writes command agents under `.github/agents`:

```text
sample-project/.github/agents/speckit.product-gate.quality-gate.agent.md
sample-project/.github/agents/speckit.product-gate.report.agent.md
```

It also writes companion prompt files under `.github/prompts`:

```text
sample-project/.github/prompts/speckit.product-gate.quality-gate.prompt.md
sample-project/.github/prompts/speckit.product-gate.report.prompt.md
```

The prompt files route to the matching Copilot agent through frontmatter:

```yaml
---
agent: speckit.product-gate.quality-gate
---
```

## 6. Spec Kit Registers Hooks

The extension manifest declares:

```yaml
hooks:
  after_plan:
    command: "speckit.product-gate.quality-gate"
    optional: false
  after_tasks:
    command: "speckit.product-gate.report"
    optional: true
```

The installed project hook state is represented in:

```text
sample-project/.specify/extensions.yml
```

Expected behavior in this POC:

- after the `speckit.plan` Copilot agent, the quality gate is mandatory
- after the `speckit.tasks` Copilot agent, the report is optional and should prompt first

## 7. User Runs Normal Spec Kit Flow

The user still runs normal Spec Kit command agents through Copilot:

```text
speckit.specify
speckit.plan
speckit.tasks
```

The extension augments the lifecycle. It does not replace the core workflow.

## 8. User Can Invoke Extension Agents Directly

Extension commands can also be dispatched directly through Copilot CLI:

```bash
copilot -p "" --agent speckit.product-gate.quality-gate
copilot -p "" --agent speckit.product-gate.report
```

This is useful when debugging or re-running a gate after updating artifacts.

## 9. Configuration Layers

The config template is:

```text
product-gate-config.template.yml
```

Project config is:

```text
.specify/extensions/product-gate/product-gate-config.yml
```

Local override should be:

```text
.specify/extensions/product-gate/product-gate-config.local.yml
```

Environment overrides follow the Spec Kit pattern:

```text
SPECKIT_PRODUCT_GATE_*
```

## 10. Catalog Discovery

A team can expose approved extensions through a catalog. This POC includes:

```text
local-catalog/catalog.json
sample-project/.specify/extension-catalogs.yml
```

In a real setup, a team would host the catalog and extension archive somewhere reachable by developers.
