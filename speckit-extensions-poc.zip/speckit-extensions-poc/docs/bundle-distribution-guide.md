# Spec Kit Bundle Distribution Guide

This guide explains how Spec Kit bundles work as a distribution layer, why catalogs matter, what a consumer must know before installing a bundle, and where the current limitations are.

The examples use this POC:

```text
extension-source/product-gate/
bundle-source/product-readiness-stack/
local-catalog/catalog.json
sample-project/
```

## Core Mental Model

A Spec Kit bundle is not the behavior itself.

```text
Extension = behavior
Preset    = template or command customization
Workflow  = repeatable multi-step process
Step      = reusable workflow step
Bundle    = curated install plan for those primitives
```

In this POC, `product-gate` is the behavior. It provides Copilot-facing commands and lifecycle hooks.

```text
speckit.product-gate.quality-gate
speckit.product-gate.report
```

`product-readiness-stack` is the bundle. It says which components belong to a product-engineering setup.

```yaml
provides:
  extensions:
    - id: "product-gate"
      version: "1.0.0"
```

So the bundle answers:

```text
"How do I install the approved product-readiness stack?"
```

The extension answers:

```text
"What behavior gets added to the Spec Kit lifecycle?"
```

## What The Bundle Owns

The bundle owns curation, version pins, and provenance.

It does not own the generated Copilot agent files. The extension installer owns those.

```text
bundle-source/product-readiness-stack/bundle.yml
  -> declares product-gate@1.0.0
  -> may later declare presets, workflows, steps, or more extensions
  -> gives the stack a stable install name

extension-source/product-gate/extension.yml
  -> declares commands, hooks, config, defaults
  -> generates integration-specific agent files during install
```

After installation, Spec Kit records bundle ownership in:

```text
.specify/bundle-records.json
```

That record is what lets Spec Kit update or remove the bundle without guessing which primitive components came from it.

## Install-Time Lifecycle

When a user runs:

```bash
specify bundle install product-readiness-stack
```

Spec Kit performs two different kinds of resolution.

```text
1. Resolve the bundle
   product-readiness-stack -> bundle artifact or bundle.yml

2. Resolve the bundle's components
   product-gate@1.0.0 -> extension artifact
```

Then it installs each primitive through that primitive's own installer.

```mermaid
flowchart TD
    A["User runs specify bundle install product-readiness-stack"] --> B["Resolve bundle from bundle catalog"]
    B --> C["Read bundle.yml"]
    C --> D["Find product-gate@1.0.0"]
    D --> E["Resolve product-gate from extension catalog, bundled source, or installed state"]
    E --> F["Run extension installer"]
    F --> G["Generate Copilot .agent.md and .prompt.md files"]
    G --> H["Register hooks in .specify/extensions.yml"]
    H --> I["Record bundle ownership in .specify/bundle-records.json"]
```

## Why Catalogs Matter

Catalogs are indexes. They tell Spec Kit where named things live.

A bundle catalog answers:

```text
"Where do I download product-readiness-stack?"
```

An extension catalog answers:

```text
"Where do I download product-gate?"
```

Even if both entries live in one physical JSON file, Spec Kit treats them as separate catalog stacks.

```text
local-catalog/catalog.json
  -> extensions.product-gate
  -> bundles.product-readiness-stack
```

But the project still has separate config surfaces:

```text
.specify/extension-catalogs.yml
.specify/bundle-catalogs.yml
```

That is why a private or org-local setup often registers the same URL twice:

```bash
specify extension catalog add https://your-org/catalog.json \
  --name your-org-extensions \
  --install-allowed

specify bundle catalog add https://your-org/catalog.json \
  --id your-org-bundles \
  --policy install-allowed
```

This is not per-item registration. One extension catalog can expose many extensions, and one bundle catalog can expose many bundles. The repeated setup is per component type.

## Bootstrapping Options

The cleanest consumer experience is:

```bash
specify bundle install product-readiness-stack
```

That works only when Spec Kit already knows where to resolve the bundle and the components inside it.

There are several ways to get there.

## Option 1: Project-Level Preconfiguration

Use this for starter repos and project templates.

Run the catalog commands once in the project:

```bash
specify extension catalog add https://your-org/catalog.json \
  --name your-org-extensions \
  --priority 5 \
  --install-allowed

specify bundle catalog add https://your-org/catalog.json \
  --id your-org-bundles \
  --priority 5 \
  --policy install-allowed
```

Commit the generated files:

```text
.specify/extension-catalogs.yml
.specify/bundle-catalogs.yml
```

Then future users of that project can run:

```bash
specify bundle install product-readiness-stack
```

This is the best model when the project itself should carry the approved catalog configuration.

## Option 2: User-Level Preconfiguration

Use this when the same developer works across many repositories.

Spec Kit extension catalogs support user-level config under:

```text
~/.specify/extension-catalogs.yml
```

Bundle docs describe a project, user, and built-in catalog stack for bundle discovery. In practice, the documented `specify bundle catalog add` command writes project-scoped config, so verify the installed CLI behavior before depending on user-level bundle catalog files for automation.

This model is useful for internal developer environments, but it is less explicit than committing project-level catalog files.

## Option 3: Bootstrap Script

Use this for internal onboarding when you cannot modify every target project in advance.

Ship one setup script or runbook:

```bash
specify extension catalog add https://your-org/catalog.json \
  --name your-org \
  --install-allowed

specify bundle catalog add https://your-org/catalog.json \
  --id your-org \
  --policy install-allowed

specify bundle install product-readiness-stack
```

This is still multiple commands, but the consumer runs one documented bootstrap path instead of learning the catalog model.

## Option 4: Direct Bundle Artifact Install

A consumer can install a local or hosted bundle artifact directly:

```bash
specify bundle install ./product-readiness-stack-1.0.0.zip
```

or:

```bash
specify bundle install https://your-org/product-readiness-stack-1.0.0.zip
```

This bypasses bundle catalog lookup because the user already supplied the bundle source.

That means this command answers the first lookup question:

```text
Where is product-readiness-stack?
```

It does not automatically answer the second lookup question:

```text
Where is product-gate@1.0.0?
```

If `bundle.yml` references `product-gate@1.0.0` by ID, Spec Kit still needs to resolve `product-gate` from one of these places:

```text
active extension catalog
already installed extension
component included inside the bundle artifact, if supported by the bundle layout
built-in/default catalog
```

For this POC, `product-readiness-stack` only references `product-gate` by ID. It does not embed the extension source. So an extension catalog is still needed unless `product-gate` is already installed.

The practical flow is:

```text
User gives bundle zip directly
  -> no bundle catalog lookup
  -> Spec Kit opens bundle zip
  -> Spec Kit reads bundle.yml
  -> Spec Kit sees product-gate@1.0.0
  -> Spec Kit resolves product-gate through extension catalog, bundled source, installed state, or defaults
  -> Spec Kit installs product-gate
  -> Spec Kit records product-readiness-stack ownership
```

So direct artifact install reduces one lookup:

```text
Skipped:
  bundle catalog lookup

Still required:
  extension, preset, workflow, or step lookup for whatever the bundle references
```

In plain terms, direct bundle artifact install tells Spec Kit where the bundle package is. It does not automatically tell Spec Kit where every item listed inside the bundle is, unless those items are also packaged inside the bundle.

## Option 5: Fully Self-Contained Bundle

This is the ideal user experience when supported by your packaging layout:

```bash
specify bundle install ./product-readiness-stack-1.0.0.zip
```

and no extra component catalogs are required because the bundle artifact carries the components it needs.

The bundle artifact would conceptually contain both the bundle manifest and the component source or artifacts:

```text
product-readiness-stack-1.0.0.zip
  -> bundle.yml
  -> product-gate extension source or artifact
  -> optional presets
  -> optional workflows
  -> optional steps
```

Now the install flow changes:

```text
User gives bundle zip directly
  -> no bundle catalog lookup
  -> Spec Kit opens bundle zip
  -> Spec Kit reads bundle.yml
  -> Spec Kit sees product-gate@1.0.0
  -> Spec Kit resolves product-gate from inside the same bundle artifact
  -> Spec Kit installs product-gate
  -> Spec Kit records product-readiness-stack ownership
```

Official guidance says bundle component references can resolve from bundled components, already installed components, or active component catalogs. If you want this model, test it from a clean Spec Kit project and document the exact bundle artifact layout that makes the components resolvable.

## Option 4 vs Option 5

Both options start with the same user command shape:

```bash
specify bundle install ./product-readiness-stack-1.0.0.zip
```

The difference is what is inside the zip.

```text
Option 4:
  Direct bundle zip, external component resolution

Option 5:
  Direct bundle zip, internal component resolution
```

Comparison:

| Question | Option 4: Direct Artifact | Option 5: Self-Contained Artifact |
| --- | --- | --- |
| Does the user need a bundle catalog? | No | No |
| Does the zip include `bundle.yml`? | Yes | Yes |
| Does the zip include `product-gate`? | No, not in this POC pattern | Yes |
| Does Spec Kit still need an extension catalog? | Usually yes, unless already installed/default | No, if the component is truly bundled |
| What is skipped? | Bundle catalog lookup only | Bundle catalog and component catalog lookup |
| Best use case | Easier bundle distribution while components stay centrally cataloged | Offline or single-file distribution of a complete stack |

For this POC today, the shape is closer to Option 4. `bundle-source/product-readiness-stack/bundle.yml` references `product-gate@1.0.0`, but the bundle source does not vendor `extension-source/product-gate`.

## Developer Distribution Checklist

Before asking consumers to install your bundle, verify each layer.

1. Validate the extension.

```bash
specify extension add --dev /absolute/path/to/extension-source/product-gate
specify extension list
```

2. Make the extension discoverable.

Your catalog needs an extension entry:

```json
"extensions": {
  "product-gate": {
    "id": "product-gate",
    "version": "1.0.0",
    "download_url": "https://your-org/product-gate-1.0.0.zip"
  }
}
```

3. Validate the bundle.

```bash
specify bundle validate --path bundle-source/product-readiness-stack
```

4. Build the bundle artifact.

```bash
specify bundle build \
  --path bundle-source/product-readiness-stack \
  --output dist
```

5. Make the bundle discoverable.

Your catalog needs a bundle entry:

```json
"bundles": {
  "product-readiness-stack": {
    "id": "product-readiness-stack",
    "version": "1.0.0",
    "download_url": "https://your-org/product-readiness-stack-1.0.0.zip"
  }
}
```

6. Test from a clean project.

```bash
specify init --here --integration copilot

specify extension catalog add https://your-org/catalog.json \
  --name your-org \
  --install-allowed

specify bundle catalog add https://your-org/catalog.json \
  --id your-org \
  --policy install-allowed

specify bundle install product-readiness-stack
```

7. Verify installed output.

```text
.specify/extensions/product-gate/
.specify/extensions.yml
.specify/bundle-records.json
.github/agents/speckit.product-gate.quality-gate.agent.md
.github/prompts/speckit.product-gate.quality-gate.prompt.md
```

## Consumer Install Paths

For a project where catalogs are already preconfigured:

```bash
specify bundle install product-readiness-stack
```

For a private project without preconfigured catalogs:

```bash
specify extension catalog add https://your-org/catalog.json \
  --name your-org \
  --install-allowed

specify bundle catalog add https://your-org/catalog.json \
  --id your-org \
  --policy install-allowed

specify bundle install product-readiness-stack
```

For direct artifact testing:

```bash
specify extension catalog add https://your-org/catalog.json \
  --name your-org \
  --install-allowed

specify bundle install ./dist/product-readiness-stack-1.0.0.zip
```

## Current Limitations

Bundles reduce repeated component installs, but they do not remove every setup concern.

First, catalogs are type-specific. Bundle discovery and extension discovery are separate. If a bundle references private extensions, those extensions must be resolvable.

Second, a bundle that only references component IDs is not self-contained. It is a manifest-driven install plan. The install succeeds only if every referenced component can be found.

Third, the first bootstrap step can be cumbersome for private catalogs. This is why project-level catalog config, user-level config, or a bootstrap script matters.

Fourth, bundle install does not replace the extension installer. It delegates to it. The generated Copilot agent files, prompt files, configs, and hooks still come from the extension.

Fifth, install-time version pinning is not the same as continuous enforcement. The official bundle docs note that idempotency checks are ID-based during install. If a component is already present, install may skip it rather than re-applying the pinned version. Use bundle update when you need to refresh owned components to the pinned versions.

Sixth, the bundle cannot override an initialized project's incompatible active integration. If a bundle targets a specific integration and the project is already initialized with another one, install should abort instead of rewriting the project unexpectedly. In this POC, the bundle is integration-agnostic and inherits the active project integration.

## Recommended Pattern For This POC

For a realistic internal distribution of this POC:

1. Host `product-gate` as an extension artifact.
2. Host `product-readiness-stack` as a bundle artifact.
3. Host one org catalog JSON containing both `extensions.product-gate` and `bundles.product-readiness-stack`.
4. Preconfigure both catalog stacks in the project template.
5. Tell consumers to run only:

```bash
specify bundle install product-readiness-stack
```

If project templates are not available, provide a bootstrap script that adds both catalogs and installs the bundle.

## Official Documentation Anchors

The official bundle reference describes bundles as a composition and distribution layer over extensions, presets, workflows, and steps:

```text
https://github.github.com/spec-kit/reference/bundles.html
```

The official extension reference describes extension catalog resolution and install behavior:

```text
https://github.github.com/spec-kit/reference/extensions.html
```

The official community bundle guidance explains that bundle catalog entries locate bundle artifacts, while components inside `bundle.yml` still need to resolve from bundled components, installed components, or active component catalogs:

```text
https://github.github.com/spec-kit/community/bundles.html
```
