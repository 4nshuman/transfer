# Product Readiness Stack Bundle

`product-readiness-stack` is a sample Spec Kit bundle. It demonstrates how a team can install a curated stack in one command instead of asking every project to install each primitive separately.

This bundle contributes one primitive in the POC:

```text
extension: product-gate@1.0.0
```

The extension still owns the actual Copilot-facing behavior. The bundle only pins, resolves, installs, updates, and removes that extension as part of a named stack.

## Why This Is A Bundle

Use the `product-gate` extension directly when you only want the product gate command and hooks.

Use this bundle when you want to distribute a role/team setup. In a real organization this bundle could grow to include a product preset, release workflow, security-review workflow, and shared steps while still being installed as one unit.

## Install From A Local Bundle Directory

From a Spec Kit project initialized with GitHub Copilot:

```bash
specify init --here --integration copilot
specify extension catalog add file:///absolute/path/to/local-catalog/catalog.json --name local-poc-catalog --install-allowed
specify bundle install /absolute/path/to/bundle-source/product-readiness-stack
```

The extension catalog is needed because the bundle manifest references `product-gate` by ID. Bundle installation resolves that ID through the normal extension machinery.

## Validate And Build

```bash
specify bundle validate --path /absolute/path/to/bundle-source/product-readiness-stack
specify bundle build --path /absolute/path/to/bundle-source/product-readiness-stack --output /absolute/path/to/dist
```

The build command creates a versioned artifact named:

```text
product-readiness-stack-1.0.0.zip
```

That artifact can be hosted and referenced from a bundle catalog.
