# Product Gate Extension

`product-gate` is a sample Spec Kit extension that demonstrates commands, config, hooks, and catalog installation for a GitHub Copilot Spec Kit project.

## Commands

```text
speckit.product-gate.quality-gate
speckit.product-gate.report
```

## Install Locally

From a Spec Kit project initialized with GitHub Copilot:

```bash
specify init --here --integration copilot
```

Then install this extension:

```bash
specify extension add --dev /absolute/path/to/product-gate
specify extension list
```

In Copilot default agent mode, Spec Kit registers extension commands under `.github/agents/*.agent.md` and creates `.github/prompts/*.prompt.md` companion files.

## Behavior

- `after_plan`: automatically runs the quality gate.
- `after_tasks`: prompts before generating the report.
- project config is loaded from `.specify/extensions/product-gate/product-gate-config.yml`.
- local overrides should use `.specify/extensions/product-gate/product-gate-config.local.yml`.
