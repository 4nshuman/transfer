#!/usr/bin/env bash
set -euo pipefail

feature_dir="${1:-}"

if [[ -z "$feature_dir" ]]; then
  echo "Usage: summarize-artifacts.sh specs/<feature>"
  exit 2
fi

for artifact in spec.md plan.md tasks.md; do
  path="$feature_dir/$artifact"
  if [[ -f "$path" ]]; then
    printf "%s: present\n" "$path"
  else
    printf "%s: missing\n" "$path"
  fi
done

