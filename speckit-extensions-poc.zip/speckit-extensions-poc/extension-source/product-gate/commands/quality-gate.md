---
description: "Review Spec Kit artifacts for product-readiness risks."
tools: []
---

# Product Gate: Quality Gate

## User Input

`$ARGUMENTS`

## Purpose

Review the current feature's Spec Kit artifacts before implementation tasks are created or executed.

This command should be run after the Copilot `speckit.plan` agent. In this extension it is registered as a mandatory `after_plan` hook.

## Inputs To Inspect

Look for the active feature directory under `specs/`.

Inspect these files when present:

- `spec.md`
- `plan.md`
- `research.md`
- `data-model.md`
- `contracts/`
- `tasks.md`
- `.specify/memory/constitution.md`
- `.specify/extensions/product-gate/product-gate-config.yml`

## Gate Rules

Apply the configured rules:

1. Count acceptance criteria in `spec.md`.
2. Confirm user stories are independently testable.
3. Confirm `plan.md` explains the architecture and technology choices.
4. Confirm a test strategy exists when `require_test_plan` is true.
5. Confirm rollback or recovery is documented when `require_rollback_note` is true.
6. Search for configured `risk_keywords` and surface risk-specific follow-ups.
7. Compare the artifacts against the project constitution.

## Output Format

Return exactly these sections:

```markdown
## Product Gate Result

Status: PASS | WARN | BLOCKED

## Evidence

- file:line - concise evidence

## Gaps

- gap and why it matters

## Required Fixes

- concrete artifact update required before implementation

## Optional Improvements

- useful but non-blocking improvement
```

## Status Semantics

- `PASS`: artifacts are implementation-ready.
- `WARN`: implementation can proceed, but there are non-blocking risks.
- `BLOCKED`: required product or engineering information is missing.

Do not write implementation code. This command only reviews and reports on Spec Kit artifacts.
