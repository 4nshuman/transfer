---
description: "Generate a product-readiness report from Spec Kit artifacts."
tools: []
---

# Product Gate: Report

## User Input

`$ARGUMENTS`

## Purpose

Generate a concise product-readiness report after the Copilot `speckit.tasks` agent.

This command is registered as an optional `after_tasks` hook. The agent should ask before running it when surfaced by the hook.

## Inputs To Inspect

- `specs/<feature>/spec.md`
- `specs/<feature>/plan.md`
- `specs/<feature>/tasks.md`
- `.specify/extensions/product-gate/product-gate-config.yml`

## Report Content

Create or update the configured report file, usually:

```text
specs/<feature>/product-gate-report.md
```

Use this structure:

```markdown
# Product Gate Report

## Summary

## User Stories Covered

## Acceptance Criteria Coverage

## Task Mapping

## Risks

## Open Questions

## Go / No-Go
```

## Rules

- Ground every finding in a specific spec, plan, or task line.
- Do not invent requirements.
- Do not mark the feature as ready if blocking ambiguity remains.
- Keep the report concise enough for PR review.
