#!/usr/bin/env python3
"""Prompt for an HLD template before Copilot starts HLD work.

This hook is intentionally conservative: it only acts on prompts that look like
high-level-design requests, and it lets all other prompts pass through.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Any


HLD_TERMS = (
    "hld",
    "high level design",
    "high-level design",
    "high level architecture",
    "high-level architecture",
    "architecture design",
    "system design",
    "design document",
    "design doc",
)

SKIP_TERMS = (
    "[hld-template:no]",
    "[hld-template:provided]",
    "[hld-template:yes]",
    "no template",
    "without a template",
    "without template",
    "use default hld",
    "use the default hld",
    "use your default hld",
    "template: none",
    "template provided",
    "template is attached",
    "template attached",
)

WORKSPACE_ROOT = Path(__file__).resolve().parents[2]
STATE_DIR = WORKSPACE_ROOT / ".github/hooks/.hld-template-gate"
LOG_PATH = WORKSPACE_ROOT / ".github/hooks/hld-template-gate.log"
DECISION_PATH = STATE_DIR / "last-decision.json"
DECISION_REUSE_SECONDS = 120


def log_event(message: str, **fields: Any) -> None:
    try:
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "message": message,
            **fields,
        }
        with LOG_PATH.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, sort_keys=True) + "\n")
    except OSError:
        pass


def emit(payload: dict[str, Any]) -> None:
    print(json.dumps(payload, separators=(",", ":")))


def collect_strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        strings: list[str] = []
        for item in value:
            strings.extend(collect_strings(item))
        return strings
    if isinstance(value, dict):
        strings = []
        for item in value.values():
            strings.extend(collect_strings(item))
        return strings
    return []


def normalized_prompt(payload: dict[str, Any]) -> str:
    prompt = payload.get("prompt")
    if isinstance(prompt, str):
        return prompt.lower()
    return "\n".join(collect_strings(payload)).lower()


def looks_like_hld_request(text: str) -> bool:
    if any(term in text for term in SKIP_TERMS):
        return False
    return any(term in text for term in HLD_TERMS)


def state_path(session_id: str) -> Path:
    safe_id = re.sub(r"[^a-zA-Z0-9_.-]", "_", session_id or "default")
    return STATE_DIR / f"{safe_id}.json"


def prompt_digest(text: str) -> str:
    return sha256(text.strip().encode("utf-8")).hexdigest()


def read_state(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except json.JSONDecodeError:
        return {}


def write_state(path: Path, state: dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")


def clear_state(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        pass


def write_decision(session_id: str, prompt_text: str, decision: str) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    DECISION_PATH.write_text(
        json.dumps(
            {
                "decision": decision,
                "hld_template_gate": True,
                "prompt_hash": prompt_digest(prompt_text),
                "session_id": session_id,
                "ts": datetime.now(timezone.utc).isoformat(),
                "ts_epoch": time.time(),
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def recent_decision(prompt_text: str) -> str | None:
    state = read_state(DECISION_PATH)
    if state.get("prompt_hash") != prompt_digest(prompt_text):
        return None
    try:
        age_seconds = time.time() - float(state.get("ts_epoch", 0))
    except (TypeError, ValueError):
        return None
    if age_seconds > DECISION_REUSE_SECONDS:
        return None
    decision = state.get("decision")
    if decision in {"yes", "no"}:
        return decision
    return None


def ask_with_macos_dialog() -> str | None:
    forced_decision = os.environ.get("HLD_TEMPLATE_GATE_DECISION", "").strip().lower()
    if forced_decision in {"yes", "no"}:
        return forced_decision

    if not Path("/usr/bin/osascript").exists():
        return None

    script = (
        'display dialog "Do you have an existing HLD template or example design '
        'document to follow? It can be outside the current open repository." '
        'buttons {"No", "Yes"} default button "No" cancel button "No" '
        'with title "HLD Template" with icon note'
    )

    try:
        result = subprocess.run(
            ["/usr/bin/osascript", "-e", script],
            check=False,
            capture_output=True,
            text=True,
            timeout=90,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None

    output = (result.stdout + result.stderr).lower()
    if "button returned:yes" in output:
        return "yes"
    if "button returned:no" in output or result.returncode == 1:
        return "no"
    return None


def main() -> int:
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        log_event("invalid-json")
        emit({"continue": True})
        return 0

    prompt_text = normalized_prompt(payload)
    session_id = str(payload.get("session_id") or payload.get("sessionId") or "default")
    log_event(
        "hook-invoked",
        session_id=session_id,
        keys=sorted(str(key) for key in payload.keys()),
        prompt_preview=prompt_text[:160],
    )

    if not looks_like_hld_request(prompt_text):
        log_event("not-hld-request", session_id=session_id)
        emit({"continue": True})
        return 0

    current_state_path = state_path(session_id)
    state = read_state(current_state_path)

    if state.get("awaiting_template_reload"):
        clear_state(current_state_path)
        log_event("allow-after-template-reload", session_id=session_id)
        emit(
            {
                "continue": True,
                "systemMessage": (
                    "HLD template gate: user previously selected Yes. Continue only "
                    "if the template is now attached, added as context, or pasted."
                ),
                "hookSpecificOutput": {
                    "hookEventName": "UserPromptSubmit",
                    "additionalContext": (
                        "HLD template gate completed: the user previously selected "
                        "Yes and was instructed to attach the template, then ask the "
                        "query again. If no template is visible in context, ask one "
                        "short clarification and stop."
                    ),
                },
            }
        )
        return 0

    previous_decision = recent_decision(prompt_text)
    if previous_decision == "no":
        log_event("reuse-recent-no", session_id=session_id)
        emit(
            {
                "continue": True,
                "systemMessage": (
                    "HLD template gate: user already selected No for this prompt. "
                    "Continue with the default HLD structure."
                ),
            }
        )
        return 0

    decision = ask_with_macos_dialog()
    log_event("dialog-decision", session_id=session_id, decision=decision)

    if decision == "yes":
        write_decision(session_id, prompt_text, decision)
        write_state(current_state_path, {"awaiting_template_reload": True})
        log_event("blocked-for-template", session_id=session_id)
        emit(
            {
                "continue": False,
                "stopReason": (
                    "HLD template requested. Add the template to the chat context "
                    "using Add Context, a #file mention, drag/drop, an open editor "
                    "tab, pasted content, or a workspace path, then ask the HLD "
                    "query again."
                ),
                "systemMessage": (
                    "Load the HLD template into the chat window, then ask the same "
                    "query again."
                ),
            }
        )
        return 0

    if decision == "no":
        write_decision(session_id, prompt_text, decision)
        log_event("allowed-default-template", session_id=session_id)
        emit(
            {
                "continue": True,
                "systemMessage": (
                    "HLD template gate: user selected No. Continue with the default "
                    "HLD structure."
                ),
                "hookSpecificOutput": {
                    "hookEventName": "UserPromptSubmit",
                    "additionalContext": (
                        "HLD template gate completed: the user selected No. Do not "
                        "ask for a template again for this request. Use the default "
                        "HLD structure and include the required ASCII diagram."
                    ),
                },
            }
        )
        return 0

    log_event("blocked-dialog-unavailable", session_id=session_id)
    emit(
        {
            "continue": False,
            "stopReason": (
                "HLD template decision required, but the template dialog could not "
                "be shown. Reply with [HLD-TEMPLATE:NO] to proceed without a "
                "template, or attach the template and reply with [HLD-TEMPLATE:PROVIDED]."
            ),
            "systemMessage": (
                "Could not show the HLD template popup. Use [HLD-TEMPLATE:NO] or "
                "[HLD-TEMPLATE:PROVIDED] in your next prompt."
            ),
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
